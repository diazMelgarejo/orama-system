# Cline routes: W&B Inference (DeepSeek) vs BigModel (GLM-5.3-Flash) — comparison, research and open questions

Date: 2026-11-12. Written by Claude Code on the Mac (model claude-sonnet-5-5, self-reported). No provider was called, nothing was changed, no key was printed.

This file combines two replies from one conversation thread:
- **Reply A** (section A): the first comparison, taken word for word from the operator's saved copy (`2026-11-12--08.12.52.textClipping.TXT`, decoded from its macOS clipping format). My first draft of this file reconstructed A from memory and got parts wrong; this version replaces it.
- **Reply B** (sections B–D): the follow-up source research, which updates and corrects some of A.

Source tiers: T1 vendor docs, T2 repos and hubs, T3 third parties. Recency weighting for ranking: Nov 2026 = 1.0, ×0.7 for each month further back (arbitrary, declared by me).

## 0. The requests that started this

1. "Can you recall from PT .agent agentic stack memory how we summon cline with WanDB and BigModel? Fetch those 2 and compare and contrast if their methods and information are symmetrical and equivalent so we can measure apples with apples and oranges with oranges?"
2. "We never choose max, so if medium is not available, all defaults should transform/fallback from medium to high instead? Before we authorize the fix and 3 calls as enumerated, EXA + Firecrawl latest sources, more weight for most recent 2026 November and less weight for October, September, and increasingly weaker signal the farther back in time those sources are from. Cast a broad net and then zoom in on particular high-signal sources. We will rationalize and fill in every missing, unknown, and outdated info here, slowly and carefully."

## A. Reply A — the first comparison (verbatim from the saved copy; table re-typeset as Markdown)

Searches run in that reply: BigModel GLM-5.3-Flash context window / max output / thinking API (1 search, 4 s); Weights & Biases Inference supported models, DeepSeek V4 Flash, context, pricing (1 search, 7 s).

> The two routes use the same summon mechanism, but they are not apples to apples yet. They differ in the model, the documented health, the settings and the cost. I read both templates, the switch script, cline-wandb, glm52-fallback and the PT recall hits. I did no live provider calls, because they need keys and cost tokens.
>
> What's symmetric:
> - Both are one JSON template in scripts/cline-provider-profiles/: bigmodel-glm52.json.tmpl and wandb-deepseek-v4-flash.json.tmpl. They have the same shape and the same openai-compatible provider slot.
> - Both are summoned the same way: switch-cline-provider.sh \<profile\>, then cline -P openai-compatible -m \<model\>. Both need the explicit -P and -m flags.
> - Both keep the key in a local env file, never in tracked files.

| Dimension | WandB route | BigModel route | Symmetric? |
| --- | --- | --- | --- |
| Model | DeepSeek-V4-Flash | GLM-5.3-Flash | No, different models. Provider and model are confounded. |
| Cline-specific documentation | cline-wandb skill, 409 lines, with a security gate | glm52-fallback: a curl and OpenClaw fallback, with no Cline invocation | No |
| Documented health through Cline | Failing: the raw API worked, but full agent dispatch returned a bare "Bad Request". It was left unresolved on 2026-08-05 with CLI 3.0.49. | Never verified through Cline | No, and neither is verified on CLI 3.0.74 |
| Policy | "wandb-only, no silent fallback" | A fallback: exit codes 7, 28 and 52 fall through to the next provider | Opposite |
| Context and output | Not recorded. Web docs say about 1M. | Skill says 131,072 and 65,536. | Stale. Z.ai's page says 1M context and 128K output. |
| Reasoning | --thinking high | Z.ai says only low, high or max, so medium silently becomes max | No. The same flag may mean different effort. |
| Template reasoning field | {"enabled": true} | {"enabled": true} | Symmetric, but both are stale. The skill's tested schema is {effort, budgetTokens}. |
| Cost | Pay per token. A July 2026 repricing to $0.14 input and $0.28 output per 1M is reported, though some pages still show $0.01. | Unrecorded | No |
| Provider timeout | 30 s in the template | 30 s in the template, with 120 s in the skill's curl policy | Inconsistent within BigModel itself |

> Smaller findings.
> - Naming drift: the BigModel file is named glm52, but its model is glm-5.3-flash.
> - Version drift: the ClinePass lane uses deepseek-v4.1-flash-1017, while W&B lists V4-Flash, V4-Flash-0731 and V4.1-Flash. I can't match these versions yet.
> - Qualification: the switch script and the W&B findings are qualified only to CLI 3.0.49. Per your earlier rule they must be re-qualified on 3.0.74.
>
> To measure like with like:
> - Hold the model constant across providers: GLM-5.3-Flash through ClinePass versus BigModel, and a DeepSeek flash model through ClinePass versus W&B once the versions match. Compare different models only inside one provider.
> - Same Cline version and flags for every run: use -P, -m, a scratch working directory, and the same prompts. Record the resolved provider, model and effort on each run, and the cost.
> - Don't use medium on BigModel, because it silently becomes max effort.
>
> Not verified: BigModel's own page, since the search only reached Z.ai's international docs, and the 3.0.74 behaviour of the openai-compatible slot. A cline --help check on the provider ids would cost nothing.
>
> Your calls:
> 1. Run a read-only check of the 3.0.74 provider ids.
> 2. Authorize one billed smoke probe per route, which needs both keys.
> 3. Open a docs and template fix PR: stale 131,072 and 65,536 numbers, the reasoning schema, and HISTORY versus LIVE labels.
>
> Sources (as given in Reply A): [Z.ai GLM-5.3-Flash](https://docs.z.ai/guides/llm/glm-5.3-flash.md), [Qubrid guide](https://www.qubrid.com/blog-news/glm-53-flash-api-the-complete-developer-guide), [W&B Inference models](https://docs.wandb.ai/inference/models.md), [W&B pricing](https://wandb.ai/site/pricing/inference), [Mastra W&B listing](https://mastra.ai/models/providers/wandb.md), [UsagePricing July repricing](https://www.usagepricing.com/blueprint/activity/weights-biases-2026-07-21-deepseek-flash-reprice).

Repo files Reply A read (diazMelgarejo/orama-system, main; paths read from origin/main, links not opened in a browser):
- [switch-cline-provider.sh](https://github.com/diazMelgarejo/orama-system/blob/main/bin/orama-system/scripts/cline-provider-profiles/switch-cline-provider.sh)
- [wandb-deepseek-v4-flash.json.tmpl](https://github.com/diazMelgarejo/orama-system/blob/main/bin/orama-system/scripts/cline-provider-profiles/wandb-deepseek-v4-flash.json.tmpl)
- [bigmodel-glm52.json.tmpl](https://github.com/diazMelgarejo/orama-system/blob/main/bin/orama-system/scripts/cline-provider-profiles/bigmodel-glm52.json.tmpl)
- [cline-wandb skill](https://github.com/diazMelgarejo/orama-system/blob/main/bin/orama-system/skills/cline-wandb/SKILL.md)
- [glm52-fallback skill](https://github.com/diazMelgarejo/orama-system/blob/main/bin/orama-system/skills/glm52-fallback/SKILL.md)

## B. Reply B — follow-up source research (17 pages scraped, scored by recency × authority)

### B1. The W&B template model id is probably stale (high confidence)
- W&B's models doc (T1) lists `DeepSeek-V4.1-Flash`, `V4.1-Flash-1017`, `V4-Flash-0731` and `V4-Pro-0813`. The bare `deepseek-ai/DeepSeek-V4-Flash` is not in the scraped list. [W&B inference models](https://docs.wandb.ai/inference/models)
- A third-party report (T3) says W&B cut its priced catalog from 28 to 20 models, removing the original V4-Flash and keeping the dated successors, and that V4.1-Flash joined the rate card at $0.20 input, $0.65 output and $0.03 cache hit per 1M tokens. Its text says Sep 21 while its URL says 2026-10-22; unverified against a W&B primary page. [usagepricing catalog-cut report](https://www.usagepricing.com/blueprint/activity/weights-biases-2026-10-22-inference-catalog-cut-to-20)
- DeepSeek (T1, Sep 9): V4-Flash retired; `deepseek-v4-flash` temporarily routes to V4.1-Flash; V4-Pro is being phased out. [DeepSeek V4.1-Flash announcement](https://www.deepseek.com/en/news/deepseek-v4-1-flash/)
- [W&B V4.1-Flash page](https://wandb.ai/site/inference-model/deepseek_deepseek-v4.1-flash/) shows a $0.03 cache-hit price.
- W&B context: 1049k for V4.1-Flash, 262k for V4-Flash-0731. The "about 1M" in Reply A's context row is unverified for the template's own model id.
- This may explain the Aug "Bad Request", but that test predates the cut, so it needs its own check.

### B2. Effort levels (no native `medium` on either route)
- DeepSeek (T1): accepted values `low` / `high` / `max`; `medium` maps to `high`, `minimal` to `low`, `xhigh` to `high`; default `high`. [DeepSeek thinking mode](https://api-docs.deepseek.com/guides/thinking_mode). So medium→high is already native on this route.
- Z.ai / BigModel (T1): `thinking.type` only supports `enabled` (cannot be disabled). The BigModel model page recommends `reasoning_effort: max`. Reply A's claim that Z.ai accepts only low/high/max, so `medium` silently becomes `max`, was not re-confirmed in the BigModel text I scraped. That would break the never-max rule without any error, so it stays flagged until checked. [BigModel GLM-5.3-Flash](https://docs.bigmodel.cn/cn/guide/models/vlm/glm-5.3-flash) · [BigModel thinking mode](https://docs.bigmodel.cn/cn/guide/capabilities/thinking-mode) · [Z.ai thinking mode](https://docs.z.ai/guides/capabilities/thinking-mode)
- Cline CLI (T1): `--thinking none|low|medium|high|xhigh`; bare `--thinking` = medium; omitted = the level last chosen with `/model`, else the provider default. `-P, --provider <id>`. [Cline CLI reference](https://docs.cline.bot/cli/cli-reference)
- Cline has no `max` option yet (open issue, Aug), and unlisted models collapse `max` to `high`. [cline #12947](https://github.com/cline/cline/issues/12947)

### B3. Cline 3.0.74 bug on this exact setup (Oct 27, T2)
Switching models with `/model` on an openai-compatible provider rewrites `providers.json` to `"reasoning": {"enabled": false}`; the next request sends `reasoning_effort: "none"`, which fails on models without `none`. Workaround: `cline --model '<id>' --thinking medium` in a fresh session. The reporter's working config carried an explicit effort; our templates carry only `{"enabled": true}`. [cline #15379](https://github.com/cline/cline/issues/15379)

### B4. Second candidate cause for the W&B "Bad Request" (hypothesis, unproven)
- DeepSeek (T1): when a request carries `tools`, earlier turns' `reasoning_content` must be passed back. [DeepSeek thinking mode](https://api-docs.deepseek.com/guides/thinking_mode)
- Cline replays tool-only assistant turns without a reasoning block, giving a 400 on `deepseek-v4.1-flash` (Oct 9, T2). [cline #14965](https://github.com/cline/cline/issues/14965)
- Z.ai asks for the same pass-back on GLM. A third-party write-up (T3, Nov 8) discusses the 400. [cheaptokens write-up](https://cheaptokens.dev/en/blog/400-after-tool-call-reasoning-content-pass-back/) · [GLM-5 issue 168](https://github.com/zai-org/GLM-5/issues/168)

### B5. BigModel GLM-5.3-Flash (T1)
- Context 1M (BigModel's own page, which also resolves Reply A's "BigModel's own page not verified"); thinking cannot be disabled; model code `glm-5.3-flash`.
- Max output 128K comes from Z.ai's page (Reply A), not yet seen on BigModel's own page.
- Pricing page shows 0.8 in / 2.8 out per million plus a free-limited-time column. Currency and what "free" covers are not confirmed. [BigModel pricing](https://docs.bigmodel.cn/cn/guide/start/pricing)
- Also listed on W&B as `zai-org/GLM-5.3-Flash` (a third route).

### B6. ClinePass (T1)
$9.99/month, 2–5× rate limits; roster includes `cline-pass/deepseek-v4.1-flash`, `-1017`, `deepseek-v4-pro`, `glm-5.3-flash`. It is a separate provider from usage-billed Cline. This confirms the ClinePass version in Reply A's "version drift" finding. [ClinePass doc](https://github.com/cline/cline/blob/main/docs/getting-started/clinepass.mdx)

### B7. Other Cline context (T2)
Discussion about explicit request-body options for exact reasoning budgets (a feature proposal, not shipped). [cline discussion 15309](https://github.com/cline/cline/discussions/15309)

## C. What changed between Reply A and Reply B

| Reply A said | After research |
| --- | --- |
| W&B lists V4-Flash, V4-Flash-0731 and V4.1-Flash | W&B's current doc lists V4.1-Flash, V4.1-Flash-1017, V4-Flash-0731 and V4-Pro-0813; the bare V4-Flash is absent. The template id is likely stale. |
| W&B cost: July repricing $0.14 in / $0.28 out | A later third-party report (T3) gives V4.1-Flash at $0.20 in / $0.65 out / $0.03 cache. Neither is checked against a W&B primary page. |
| BigModel's own page not verified | Scraped: 1M context, thinking enabled-only, recommends `reasoning_effort: max`. |
| "medium silently becomes max" (Z.ai) | Still unconfirmed in BigModel's text. |
| Context/output "1M and 128K" (Z.ai) | Context confirmed by BigModel; 128K output still from Z.ai only. |
| Bad Request cause unknown | Two hypotheses added: stale model id, and missing `reasoning_content` pass-back on tool turns. |
| 3.0.74 behaviour not verified | Known bug for the openai-compatible slot (#15379), so the `--thinking medium` flag should be explicit. |

## D. Still unknown
- Whether W&B serves the template's bare model id today (one authenticated model-list call settles it; not billed).
- Whether BigModel's `medium` really maps to `max`.
- BigModel's own max-output number, and the currency on the pricing page.
- Whether `cline --help` in 3.0.74 still accepts the provider ids the switch script uses.
- W&B effort support (the doc and V4.1 page say nothing).
- Which W&B price is current ($0.14/$0.28 July report vs $0.20/$0.65 Sep report vs the "$0.01" some pages show).

## E. Questions for the operator, with no answers yet
1. **Effort rule scope.** Does "never choose max" also exclude `xhigh`? Proposed rule: use `medium` if offered, else `high`, never `xhigh` or `max`. Does it apply to templates, skills and the Cline flag?
2. **Providers offering only low and max.** Pick `low`, or fail with an error? Suggestion: fail with an error, so nothing silently drops to `low`.
3. **Which W&B model id** for the fix: `deepseek-ai/DeepSeek-V4.1-Flash` or `deepseek-ai/DeepSeek-V4.1-Flash-1017`.
4. **Authorization of the three calls from Reply A, as revised:**
   - Call 1, read-only and free: `cline --help` on 3.0.74, plus a model-list GET to W&B (needs the W&B key; may I use it?).
   - Call 2, billed: one smoke probe per route after ids are corrected, with explicit `--thinking medium` on a tool-using turn (tests the pass-back hypothesis); needs both keys and the operator's go.
   - Call 3, fix PR in orama-system: update the W&B id, fix the reasoning schema, rename the `glm52` template, mark HISTORY vs LIVE in `cline-wandb`, update the stale 131,072/65,536 limits, encode the effort rule, and align the BigModel 30 s vs 120 s timeout.

## F. Update (2026-11-12, after live probes): rulings and answers
- **Final effort rule (operator):** `medium`, else `high`, else `low`; never `xhigh` or `max`. This answers questions E1 and E2 above.
- **E3 (W&B model id):** live list checked. The bare `deepseek-ai/DeepSeek-V4-Flash` is gone (404). `V4.1-Flash` and `V4.1-Flash-1017` both accept `high` and `low` and reject `medium`. Recommended pick: `V4.1-Flash-1017` (DeepSeek's current served version); the operator's decision is still pending.
- **E4 (authorizations):** the free list call and the billed probes were run; BigModel remains official-docs-only (payment blocked).
- **Corrections to this file:** BigModel `medium` on GLM-5.3-Flash is an explicit 400, not a silent `max`; BigModel's 131,072 / 65,536 are max and default output, context is 1M; the `reasoning_content` pass-back hypothesis did not reproduce on W&B; the bare "Bad Request" matches `medium` being rejected on V4.1.
- Full evidence and sources: `2026-11-12-live-probe-results-wandb-bigmodel-cline.md` (sections 2-10).
- **Model order rule (operator, final):** `*4.1-Flash-1017` first whenever available, then the generic alias, then `*4-Flash`. On W&B that maps to `V4.1-Flash-1017`, `V4.1-Flash`, `V4-Flash-0731`; the `deepseek-flash` alias itself exists on DeepSeek's own API, not in W&B's live list. This answers E3.
- PR plan: `2026-11-12-cline-provider-fix-pr-plan.md` (draft, for manual review, nothing executed).
