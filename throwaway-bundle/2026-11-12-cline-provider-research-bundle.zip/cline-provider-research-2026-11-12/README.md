# Cline provider research bundle — W&B Inference (DeepSeek) vs BigModel (GLM-5.3-Flash), 2026-11-12

Prepared by Claude Code on the Mac (claude-sonnet-5-5, self-reported) for the operator's manual review. **The fix is implemented LOCALLY on branch `2026-11-12-001-cline-provider-live-fixes` (two commits `c831947f` and `912bb0f3`, based on origin/main `23059e8f`). It is NOT pushed and there is NO PR: publishing to GitHub is on hold by the operator.** No secrets are in this bundle (scanned against the live key values and common key shapes). Source tiers: LIVE = observed today, OFFICIAL = vendor docs (BigModel's Chinese pages translated), T3 = third party.

## Read in this order
| # | File | What it is |
| --- | --- | --- |
| 1 | `01-PR-PLAN-draft-v2.md` | The guided plan for the fix PR (tasks, files, tests, risks, operator decisions). Start here. |
| 2 | `02-live-probe-results.md` | What the providers actually do today: model lists, effort tests, Cline 3.0.74 runs, official BigModel facts, DeepSeek 1017 rationale, alias and OpenRouter checks. |
| 4 | `04-branch-orama-system.patch` | Both orama-system commits as a patch series (`git am` on origin/main `23059e8f`). |
| 5 | `05-branch-perpetua-tools-lesson.patch` | The PT lesson commit (separate local PT branch `2026-11-12-001-effort-recheck-lesson`). |
| 3 | `03-comparison-and-research.md` | Reply A (your saved original comparison, verbatim), the source research, and what changed between them. |
| raw/ | key-scrubbed outputs | `effort_probe*.txt`, `toolturn_probe.txt`, `alias_probe.txt`, `cline_*` run logs. |
| sources/ | inputs | Reply A as decoded text, the Perplexity distilled-conversations file, BigModel's official parameter and error-code pages (Chinese originals). |

## Rules decided by the operator (final)
- **Effort:** `medium`, else `high`, else `low`. Never `xhigh` or `max`. Always sent explicitly (BigModel defaults to `max` if omitted).
- **Model order (W&B):** `deepseek-ai/DeepSeek-V4.1-Flash-1017` → `deepseek-ai/DeepSeek-V4.1-Flash` → `deepseek-ai/DeepSeek-V4-Flash-0731` → `deepseek-ai/deepseek-flash` only if the provider serves it. W&B does not (404), so it is dropped there.
- Resolver effort probe is opt-in (billed); rename BigModel template to `bigmodel-glm53-flash` with the old name kept as an alias; harmonize every live file so no stale tail remains (historical dated records stay untouched, listed in a ledger).

## Headline results (LIVE unless marked)
- The W&B template's bare `deepseek-ai/DeepSeek-V4-Flash` returns 404: the template is broken.
- W&B `V4.1-Flash` and `V4.1-Flash-1017` reject `medium` (HTTP 400 "Invalid request", the bare "Bad Request" seen in August) and accept `high` and `low`. `V4-Flash-0731`, `V4-Pro-0813` and `GLM-5.2` accept `medium`. Cline 3.0.74 reproduced the failure with `--thinking medium` and passed with `high`.
- The `reasoning_content` pass-back hypothesis did not reproduce on W&B.
- BigModel is blocked by the account balance (error 1113), so it is official-docs-only: GLM-5.3-Flash accepts only `low`/`high`/`max` (default `max`), context 1M, default output 65,536, max 131,072; `medium` is an error (1210), not a silent `max`.
- DeepSeek (OFFICIAL): `1017` is the 2026-10-17 upgrade of V4.1-Flash, a performance-cost improvement, and the version DeepSeek's `deepseek-flash` alias now serves.
- OpenRouter's live list has no `deepseek-v4-flash:free`; four tracked files still list it.

## Effort cadence (operator, after a side-agent note)
The checked-in `high` applies on every switch (so rule and syntax updates stay applied); the medium, high, low walk (`--resolve --verify-effort`) is a periodic, reviewed re-check during repository updates, not a per-switch billed cost. Documented in the skills and script; PT lesson `lesson_7d306abe607f`; private memory updated.

## What the branch changed (tests green)
- Templates: W&B now `V4.1-Flash-1017` with an ordered `resolution` block and explicit effort; BigModel renamed `bigmodel-glm53-flash` (old name still accepted) with explicit `high`.
- `switch_cline_provider.py`: pure resolver helpers plus opt-in `--resolve` (free) and `--verify-effort` (billed). Inconclusive probes (balance, auth, rate limit) never read as "rejected".
- Skills and config: `cline-wandb` and `glm52-fallback` updated with live/official facts and HISTORY vs LIVE labels; the BigModel setup probe now sends an explicit effort; `mac-orchestrator.json` context window corrected.
- All six dead OpenRouter `:free` ids replaced by live ones chosen per role and probed (results section 13); `docs/stale-reference-ledger-2026-11-12.md` classifies dated records as HISTORICAL, NOT LIVE (they were left unedited because of old lint debt).
- Verified live: resolver picked `V4.1-Flash-1017` at `high` on W&B; Cline 3.0.74 ran a tool task with the new values.

## Still open
- BigModel through Cline and a BigModel tool-turn probe (blocked by payment).
- ClinePass route not probed.
- Which of the three conflicting W&B prices is current.
- Publishing: push, PR and merge all wait for the operator.
- Web UI mock labels still show old OpenRouter ids (needs a change with its own test); `mac-orchestrator.json` still has a zero cost for glm-5.3-flash; Gemma 4 free models were rate-limited at probe time and should be re-tried later.

## Caveats
Reply A in `sources/` is the original text; the rest is my analysis. Some `02` sections are numbered out of order (9 before 8); content is unaffected. Links in the reports were not all opened in a browser.
