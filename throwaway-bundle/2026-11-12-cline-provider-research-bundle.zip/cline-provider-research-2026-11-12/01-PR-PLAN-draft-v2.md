# Plan: Cline provider fix PR (orama-system) — DRAFT v2 for manual review, nothing executed

> **STATUS (2026-11-12, after operator go "update all live code"):** EXECUTED LOCALLY, NOT PUSHED, NO PR.
> Branch `2026-11-12-001-cline-provider-live-fixes` in a separate worktree, two commits `c831947f` and `912bb0f3`
> (author Claude, approved identity), based on origin/main `23059e8f`. The patch is in this bundle
> (`04-branch-orama-system.patch`, both commits; `05-branch-perpetua-tools-lesson.patch`). Publishing to GitHub is on hold by the operator.
>
> Deviations from this plan, with reasons:
> 1. Dated historical records were **not edited** (no banners): 14 of them carry old markdown-lint
>    debt that blocks any commit touching them, and reflowing history is noise. They are classified
>    HISTORICAL, NOT LIVE in `docs/stale-reference-ledger-2026-11-12.md` instead.
> 2. More dead ids found than planned: 6 of the 7 OpenRouter `:free` ids in the free-tier stack were
>    absent live. All six were replaced in a second commit with live ids chosen per role and probed
>    (see results section 13); web UI mock labels were left for a change with its own test.
> 3. `bigmodel-glm52.json.tmpl` was renamed with git's whole-file-deletion guard overridden through
>    its documented, justified mechanism (operator-approved rename; old profile name kept as an alias).
> 4. `config/mac-orchestrator.json`: context window corrected to 1M; the zero cost entry was left
>    alone (the official price list has a "free for a limited time" column that was not interpreted).
> 5. The ClinePass skill and its wrapper already used `cline-pass/deepseek-v4.1-flash-1017` with
>    `medium`; left unchanged (not probed live).
> 6. Live checks done: resolver with probes returned `(V4.1-Flash-1017, high)` on W&B; BigModel returned
>    an inconclusive 429 (balance), so the config would be left unchanged by design; Cline 3.0.74 ran
>    a tool task with the new template values (pass, 3.9 s).

v2 (2026-11-12): operator answers folded in; scope widened to remove every stale or vestigial tail; OpenRouter and alias facts checked live.

Date: 2026-11-12. Base: orama-system origin/main `23059e8f` (PR 492 merge). Evidence: `2026-11-12-live-probe-results-wandb-bigmodel-cline.md` (sections 2-10). Complexity: Medium (about about 20 files, one new resolver function, tests; no runtime service changes).

## Requirements (restated)
1. **Model order, always (operator-final):** on W&B `deepseek-ai/DeepSeek-V4.1-Flash-1017` → `deepseek-ai/DeepSeek-V4.1-Flash` → `deepseek-ai/DeepSeek-V4-Flash-0731` → `deepseek-ai/deepseek-flash` last *if the provider serves it as documented*. **Checked live: W&B returns 404 for both `deepseek-ai/deepseek-flash` and `deepseek-flash`, so on W&B the alias is dropped.** The alias stays last in lists for providers that do serve one: DeepSeek's own API (`deepseek-flash`) and OpenRouter (`~deepseek/deepseek-flash-latest`, live in its model list). The resolver skips any candidate the provider does not list.
2. **Effort order, always:** `medium` → `high` → `low`. Never `xhigh` or `max`. Always sent explicitly (BigModel defaults to `max` when omitted). If none is accepted, the route is reported blocked; nothing silently changes.
3. Grounded in what providers actually serve (live evidence), not textual conformity. Where a provider can't be called (BigModel balance), cite official docs.
4. Keep compatibility aliases, keep secrets out of tracked files, no workstation paths (LINT-006), portable-memory rules.

## Live facts the plan relies on
- W&B: bare `deepseek-ai/DeepSeek-V4-Flash` → 404 (template broken). `V4.1-Flash` and `V4.1-Flash-1017`: `medium` → 400 "Invalid request", `high`/`low` → 200. `V4-Flash-0731`, `V4-Pro-0813`, `GLM-5.2`: `medium` → 200. `GLM-5.3-Flash` on W&B: all three levels 200, 23-30 s per call.
- BigModel `glm-5.3-flash`: `medium` → 400 (code 1210); only low/high/max valid; default `max`; context 1M, default output 65,536, max 131,072 (official). Live calls blocked by account balance (1113); official-docs-only.
- Cline 3.0.74: `--thinking none|low|medium|high|xhigh`; `--config <dir>` isolates the provider slot per run; `/model` can drop reasoning metadata (cline #15379), so effort must be explicit.

## Patterns to mirror (grounded in the repo)
| Category | Source | Pattern |
| --- | --- | --- |
| Template shape | `bin/orama-system/scripts/cline-provider-profiles/*.json.tmpl` | `{"settings": {...}}` with `${ENV}` placeholders; the script reads only `["settings"]`, so sibling keys are safe |
| Switch logic | `.../switch_cline_provider.py` | pure functions, atomic write, never mutate in place, `SystemExit("ERROR: ...")` on unset env var, microsecond-stamped rotating backups |
| Tests | `tests/test_switch_cline_provider.py` | pytest, module loaded via `importlib` from its path, `Workspace` fixture with tmp_path, no network |
| Skill docs | `bin/orama-system/skills/cline-wandb/SKILL.md`, `.../glm52-fallback/SKILL.md` | long SKILL.md with a Reasoning section; fallback skill has a test file `tests/test_glm52_fallback_skill.py` that may assert the numbers I will change (check first) |
| Provider config shape | operator's `providers.json` other providers | `reasoning: {"enabled": true, "effort": "medium"}` (and the skill states `{effort, budgetTokens}`), so templates should carry `effort` too |

## Files to change
| File | Action | Why |
| --- | --- | --- |
| `.../cline-provider-profiles/wandb-deepseek-v4-flash.json.tmpl` | UPDATE | model → `...V4.1-Flash-1017`; `reasoning` gains `effort`; add sibling `"resolution"` block listing ordered model and effort candidates; keep file name (compat) |
| `.../cline-provider-profiles/bigmodel-glm52.json.tmpl` | UPDATE (keep) | explicit `effort: "high"` (never default `max`); add `resolution` effort order; keep the old name working |
| `.../cline-provider-profiles/bigmodel-glm53-flash.json.tmpl` | CREATE | correctly named copy; `bigmodel-glm52` stays as an alias so existing callers don't break |
| `.../cline-provider-profiles/switch_cline_provider.py` | UPDATE | new pure helpers: `choose_first_available(candidates, live_ids)`, `choose_effort(candidates, probe)`; `resolve_template` applies the chosen model/effort; no network inside pure functions |
| `.../cline-provider-profiles/switch-cline-provider.sh` | UPDATE | optional `--resolve` (free GET /models list, key from env, never printed) and `--verify-effort` (billed, opt-in, tiny prompt) flags; default behaviour unchanged |
| `bin/orama-system/skills/cline-wandb/SKILL.md` | UPDATE | model id/order, effort order, `--thinking` examples, HISTORY vs LIVE labels, link to the live results, `OpenAI-Project` 401 note kept |
| `bin/orama-system/skills/glm52-fallback/SKILL.md` | UPDATE | context 1M (not 131,072); max output 131,072, default 65,536; timeout note (30 s template vs 120 s curl policy, and W&B GLM latency 23-30 s); official-docs-only label for BigModel facts |
| `.env.local.example` | UPDATE | comment names the current model, not `DeepSeek-V4-Flash` |
| `bin/orama-system/references/interactive-provider-setup.md` + `scripts/interactive-provider-setup.sh` | UPDATE (check) | same model-name drift, if they hard-code it |
| `tests/test_switch_cline_provider.py` | UPDATE | resolver tests (below) |
| `tests/test_cline_provider_templates.py` | CREATE | static template checks (below) |
| `tests/test_glm52_fallback_skill.py` | UPDATE (if it asserts old numbers) | keep green |
| `config/mac-orchestrator.json` (glm-5.3-flash block) | UPDATE | `contextWindow` 131072 is wrong (official: 1M); `maxTokens` 65536 is the default, max is 131072; `cost` 0/0 conflicts with the official price list (0.8/2.8 CNY per 1M; "free for a limited time" column) so flag it, do not invent a number |
| `bin/orama-system/skills/clinepass-deepseek-flash/SKILL.md` | UPDATE | harmonize with the model-order rule (`cline-pass/deepseek-v4.1-flash-1017` first); keep the retirement history as dated history |
| `bin/orama-system/skills/openclaw-skills/SKILL.md`, `.../references/openrouter-defaults.md`, `skills/mcp-orchestration/SKILL.md`, `docs/OPENROUTER_FREE_MODELS.md` | UPDATE | all list `openrouter/deepseek/deepseek-v4-flash:free`; **live OpenRouter list has no `:free` variant** (it has `deepseek/deepseek-v4.1-flash-1017`, `v4.1-flash`, `v4-flash-0731`, `v4-flash` and the alias `~deepseek/deepseek-flash-latest`). Replace with the live ids and the same model order; verify the free-tier claim before keeping the word "free" |
| `infra/deployments/.../openclaw.model-policy.jsonc` (+ its twin under `deployments/`) | UPDATE (check) | alias `Free-DeepSeek-V4-Flash` and 131072 entries; keep the two copies identical (they are twins) |
| `bin/orama-system/references/interactive-provider-setup.md`, `scripts/interactive-provider-setup.sh`, `scripts/fallback-chain-verify.sh` | UPDATE (check) | already say glm-5.3-flash; confirm wording and add the effort/limit facts only where they state limits |
| `skills/hermes-harness/SKILL.md`, `skills/cline-openclaw-agent/SKILL.md`, `skills/openrouter-fallback/SKILL.md` | CHECK, minimal edit | they mention `glm52` only as file/env names (`setup-glm52.sh`, `.env.glm52`, `GLM52_API_KEY`); those identifiers are load-bearing and must NOT be renamed. Add a one-line "legacy name, model is glm-5.3-flash" note |

## Tasks (TDD: tests first, run RED, then GREEN)
1. **Branch and baseline.** `git fetch`; branch `2026-11-12-001-cline-provider-live-fixes` from origin/main `23059e8f` in a fresh worktree (the current checkout has unrelated local edits: do not touch them). Run the existing tests for the three touched areas to record a green baseline.
2. **RED, template tests** (`test_cline_provider_templates.py`): every `.tmpl` parses; the only `${...}` names are the documented env vars; `effort` is present and in {medium, high, low}; no `xhigh`/`max`; W&B model order list starts with `*4.1-Flash-1017`; no keys or hosts of the LAN in the files.
3. **RED, resolver tests** (pure functions, stubs for live ids and probe): picks 1017 when listed; falls to unsuffixed then `*4-Flash` when earlier ones are missing or rejected; effort `medium` rejected → `high`; `high` rejected → `low`; all rejected → returns a blocked result, not a guess; never returns `xhigh`/`max` even if offered.
4. **GREEN, resolver** in `switch_cline_provider.py`: pure helpers plus thin HTTP wrappers (stdlib only, explicit CA bundle env, hard 60 s ceiling, key only via environment, errors scrubbed of the key). Keep Windows parity (the file already branches on `fcntl`/`msvcrt`).
5. **GREEN, templates:** edit the W&B template and both BigModel templates per the table; confirm the switch script still renders them (`resolve_template` ignores `resolution`).
6. **Shell wrapper flags** in `switch-cline-provider.sh` (zsh/bash safe, no stored commands in variables, no unquoted `=` words).
7. **Docs/skills:** update the two skills and the env example; add HISTORY vs LIVE labels with the probe date; cross-link `references/` results (relative links only; no `/Users/...` paths).
7b. **Stale-tail sweep:** `git grep` for the dead ids (`DeepSeek-V4-Flash` bare, `:free` OpenRouter id, `131072` as a context window, `glm52` as a model name) across the live tree; every hit is either fixed, noted as a load-bearing legacy name, or listed in the new stale-reference ledger. Add a test that fails if a dead W&B/OpenRouter id re-enters a template or skill.
8. **Verify:** full run of the touched test files; `scripts/repo_hygiene.py` (LINT-006/007) and the privacy/portable-memory scan; `git diff --diff-filter=U` and the pre-push hook as usual.
9. **Live qualification (needs your explicit go; billed, tiny):** with a throwaway `--config` directory run Cline 3.0.74 against W&B `1017` with the resolver-chosen effort and one tool-using prompt; then the `V4.1-Flash` and `V4-Flash-0731` fallbacks once each. BigModel stays official-docs-only. Record results in the references folder.
10. **Review and PR:** code-reviewer agent on the diff (security-reviewer for the key-handling code); PR description cites the live evidence and the official sources; commit messages end with the required attribution lines; push only after you approve.
11. **Lessons:** PT lesson via `learn.py` (never hand-edit): "W&B V4.1 rejects `medium`; verify live ids before templating"; no names, hosts or paths in it.

## Risks
| Risk | Likelihood | Mitigation |
| --- | --- | --- |
| W&B catalog churns again (ids vanish) | High | `--resolve` free list check at switch time; ordered candidates; fail loudly |
| "Generic alias" mapped wrongly | Medium | confirm assumption before step 5 |
| Cline ignores `reasoning.effort` from `providers.json` on 3.0.74 | Medium | step 9 verifies; docs say pass `--thinking` explicitly |
| Shared `providers.json` contaminates concurrent runs | Medium | recommend `--config` per run in the skill; script already locks writes |
| BigModel can't be live-tested (balance) | Certain | official-docs-only labels; no claims beyond sources; revisit after recharge |
| Billed probes surprise cost | Low | opt-in flag, tiny prompts, per-run cap, your go required |
| Old callers use `bigmodel-glm52` / the dead W&B id | Medium | keep aliases; grep callers in step 8 |
| Secret leakage in tests/logs | Low | fake env values, key scrubbing, scan before commit |

## Acceptance
- [ ] Templates carry the live-verified model and an explicit allowed effort; no `xhigh`/`max` anywhere
- [ ] Resolver tests prove the model order and the medium → high → low order, including the blocked case
- [ ] Skills show correct limits and HISTORY vs LIVE labels
- [ ] Hygiene and privacy scans clean; existing tests green
- [ ] Live Cline 3.0.74 qualification recorded (after your go)
- [ ] PR opened only after your explicit approval

## Operator decisions (2026-11-12)
1. Model order as in requirement 1 (alias last, dropped where not served). Confirmed.
2. Billed effort probe is opt-in only. Confirmed.
3. Rename to `bigmodel-glm53-flash`, keep `bigmodel-glm52` as an alias. Confirmed.
4. Nothing stays out of scope in the live/operational tree: harmonize everything so no stale or vestigial tails remain. Historical records are the exception (below).

## What was "out of scope" and why (answering the operator's question)
- **I had put these aside** because they are not Cline provider files: the Hermes skill, the OpenClaw model-policy alias, `start.sh` / `start.ps1`, the OpenRouter lists. Reason: a smaller diff is easier to review, and I had not checked whether they pin a dead id. Your point is right: leaving them makes stale tails, so the live ones move in scope (table above).
- **`start.sh` and `platform/windows/start.ps1`:** the grep found no model id or limit in them (only "reasoning engine" wording), so there is nothing to harmonize; verify again in step 8.
- **Still deliberately untouched, with reasons:**
  - Dated historical records: `docs/archive/**`, `docs/plans/**`, `docs/superpowers/plans/**`, `docs/security/glm52-clean-replay-record.md`, `docs/LESSONS.md`, `.agent/memory/working/**`, `.superpowers/sdd/**`. They describe what was true on their date; rewriting them falsifies history (additive-content rule). Instead add a single "stale-reference ledger" file in `docs/` listing which old ids/limits they mention and the current replacement.
  - Load-bearing legacy identifiers: `GLM52_API_KEY`, `.env.glm52`, `setup-glm52.sh`, `glm52-fallback/` directory name. Renaming them breaks installed machines; they get a "legacy name" note only.

**WAITING FOR CONFIRMATION**: nothing has been written to the repo.
