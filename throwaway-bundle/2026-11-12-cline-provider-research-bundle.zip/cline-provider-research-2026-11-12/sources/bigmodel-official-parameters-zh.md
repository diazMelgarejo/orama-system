> ## Documentation Index
> Fetch the complete documentation index at: https://docs.bigmodel.cn/llms.txt
> Use this file to discover all available pages before exploring further.

# 核心参数

> [!TIP]
>
> 在与模型进行交互时，您可以通过调整不同的参数来控制模型的输出，以满足不同场景下的需求。理解这些核心参数将帮助您更好地利用模型的能力。

## 快速参考

| 参数 | 类型 | 默认值 | 描述 |
| :- | :- | :- | :- |
| [do\_sample](#do_sample) | 布尔值 | `true` | 是否对输出进行采样，以增加多样性。 |
| [temperature](#temperature) | 浮点数 | (依赖模型) | 控制输出的随机性，值越高越随机。 |
| [top\_p](#top_p) | 浮点数 | (依赖模型) | 通过核采样控制多样性，建议与 `temperature` 二选一。 |
| [max\_tokens](#max_tokens) | 整数 | (依赖模型) | 限制单次调用生成的最大 token 数。 |
| [stream](#stream) | 布尔值 | `false` | 是否以流式方式返回响应。 |
| [thinking](#thinking) | 对象 | `{"type": "enabled"}` | 是否开启思维链深度思考，仅 `GLM-4.5` 及以上支持。 |
| [reasoning\_effort](#reasoning_effort) | 字符串 | `max` `high` `low` | 控制模型的推理程度，仅 `GLM-5.2` 及以上支持。 |

***

## 参数详解

### do\_sample

`do_sample` 是一个布尔值（`true` 或 `false`），用于决定是否对模型的输出进行采样。

* `true` (默认值): 根据每个 token 的概率分布进行随机采样，增加文本的多样性和创造性。适用于内容创作、对话等场景。
* `false`: 采用贪心策略，总是选择概率最高的下一个 token。输出确定性高，适用于需要精确、事实性回答的场景。

最佳实践:

* 需要可复现、确定性的输出时，设为 `false`。
* 希望模型生成更多样、更有趣的内容时，设为 `true`，并配合 `temperature` 或 `top_p` 使用。

### temperature

`temperature`（温度）参数控制着模型输出的随机性。

* 较低的值 (如 0.2): 概率分布更“尖锐”，输出更具确定性、更保守。
* 较高的值 (如 0.8): 概率分布更“平缓”，输出更具随机性和多样性。

最佳实践:

* 在需要严谨、事实准确的场景（如知识问答），建议使用较低的 `temperature`。
* 在需要创意的场景（如内容创作），可以尝试较高的 `temperature`。
* 建议 `temperature` 和 `top_p` 只使用其中一个。

### top\_p

`top_p`（核采样）通过从累积概率超过阈值的最小 token 集合中进行采样来控制多样性。

* 较低的值 (如 0.2): 限制采样范围，输出更具确定性。
* 较高的值 (如 0.9): 扩大采样范围，输出更具多样性。

最佳实践:

* 如果希望在保证内容质量的同时获得一定的多样性，`top_p` 是一个很好的选择（推荐值 0.8-0.95）。
* 通常不建议同时修改 `temperature` 和 `top_p`。

### max\_tokens

`max_tokens` 用于限制模型单次调用生成的最大 token 数量。GLM-4.6 最大支持 128K 输出长度，GLM-4.5 最大支持 96K 输出长度，建议设置不小于 1024。令牌是文本的基本单位，通常 1 个令牌约等于 0.75 个英文单词或 1.5 个中文字符。设置合适的 max\_tokens 可以控制响应长度和成本，避免过长的输出。如果模型在达到 max\_tokens 限制前完成回答，会自然结束；如果达到限制，输出可能被截断。

* 作用: 防止生成过长文本，控制 API 调用成本。
* 注意: `max_tokens` 限制的是生成内容的长度，不包括输入。

最佳实践:

* 根据应用场景合理设置 `max_tokens`。如果需要简短回答，可设为较小的值（如 50）。

各模型的默认 `max_tokens` 和支持的最大 `max_tokens`:

| 模型编码 | 默认 max\_tokens | 最大 max\_tokens |
| :- | :-: | :-: |
| glm-5.3 | 65536 | 131072 |
| glm-5.3-flash | 65536 | 131072 |
| glm-5.3-flashx | 65536 | 131072 |
| glm-5.2 | 65536 | 131072 |
| glm-5.1 | 65536 | 131072 |
| glm-5v-turbo | 65536 | 131072 |
| glm-5 | 65536 | 131072 |
| glm-5-turbo | 65536 | 131072 |
| glm-4.7 | 65536 | 131072 |
| glm-4.6 | 65536 | 131072 |
| glm-4.6v | 16384 | 32768 |
| glm-4.6v-flash | 16384 | 32768 |
| glm-4.6v-flashx | 16384 | 32768 |
| glm-4.5 | 65536 | 98304 |
| glm-4.5-air | 65536 | 98304 |
| glm-4.5-x | 65536 | 98304 |
| glm-4.5-flash | 65536 | 98304 |
| glm-4.5v | 16384 | 16384 |
| glm-4.1v-thinking-flashx | 16384 | 16384 |
| glm-4.1v-thinking-flash | 32768 | 32768 |
| glm-4-air-250414 | 16384 | 16384 |
| glm-4-flash-250414 | 32768 | 32768 |
| glm-4-plus | 动态计算 | 4095 |
| glm-4-air | 动态计算 | 4095 |
| glm-4-airx | 动态计算 | 4095 |
| glm-4-flash | 动态计算 | 4095 |
| glm-4-flashx | 动态计算 | 4095 |
| glm-4v-plus-0111 | 1024 | 8192 |
| glm-4v-flash | 1024 | 1024 |

### stream

`stream` 是一个布尔值，用于控制 API 的响应方式。

* `false` (默认值): 一次性返回完整的响应，实现简单但等待时间长。
* `true`: 以流式（SSE）方式返回内容，显著提升实时交互应用的体验。

最佳实践:

* 对于聊天机器人、实时代码生成等应用，强烈建议设为 `true`。

### thinking

`thinking` 参数用于控制模型是否开启“思维链”（Chain of Thought），以进行更深度的思考和推理。

* 类型: 对象
* 支持模型: `GLM-4.5` 及以上

属性:

* `type` (string):
  * `enabled` (默认): 开启思维链。`GLM-5.3` `GLM-5.3-FLASH` `GLM-5.3-FLASHX` 强制需开启。其它模型 `GLM-5.2` `GLM-5.1` `GLM-5` `GLM-5-Turbo` `GLM-5v-Turbo` `GLM-4.6` `GLM-4.6V` `GLM-4.5` 为模型自动判断是否思考，`GLM-4.7` `GLM-4.5V` 为强制思考。
  * `disabled`: 关闭思维链。

最佳实践:

* 在需要模型进行复杂推理、规划时，建议开启。
* 对于简单任务，可关闭以获得更快响应。

### reasoning\_effort

`reasoning_effort` 参数用于控制模型在开启“思维链”下的推理程度。

* 类型: 字符串

* 支持模型: `GLM-5.2` 及以上

* 参数支持: `max` `high` `low`

* `low`: 轻量思考

* `high`: 增强思考

* `max`: 深度思考（默认值）

注意:

* `GLM-5.2` 模型支持 `max` `xhigh` `high` `medium` `low` `minimal` `none`, 传入 `none` 或 `minimal` 模型会放弃思考；传入 `low` `medium` 将映射为 `high`；传入 `xhigh` 将映射为 `max`"。
* `GLM-5.3` `GLM-5.3-FLASH` `GLM-5.3-FLASHX` 模型仅支持 `max` `high` `low`

***

## 相关概念

> [accordion] Token 用量计算
>
> Token 是模型处理文本的基本单位。用量计算包括输入和输出两部分。
>
> * **输入 Token 数:** 您发送给模型的文本所包含的 token 数量。
> * **输出 Token 数:** 模型生成的文本所包含的 token 数量。
> * **总 Token 数:** 输入与输出之和，通常为计费依据。
>
> 您可以调用 `tokenizer` 分词器 API 来预估文本的 token 数量。

> [accordion] 最大输出 Tokens
>
> 最大输出 Tokens 是指模型在单次请求中能够生成的最大 Token 数量。它与 `max_tokens` 参数不同，`max_tokens` 是您在请求中设置的上限，而最大输出 Tokens 是模型本身的架构限制。
>
> 例如，一个模型的上下文窗口可能是 8k Tokens，但其最大输出能力可能被限制在 4k Tokens。

> [accordion] 上下文窗口
>
> 上下文窗口（Context Window）是指模型在一次交互中能够处理的总 Token 数量，它包括了**输入文本**和**生成文本**的所有 Token。
>
> * **重要性:** 上下文窗口决定了模型能“记住”多少历史信息。如果输入和期望输出的总长度超过了模型的上下文窗口，模型将无法处理。
> * **注意:** 不同模型的上下文窗口大小不同。在进行长对话或处理长文档时，需要特别关注上下文窗口的限制。

> [accordion] 并发数权益
>
> 并发数（Concurrency）是指您在同一时间内可以发起的 API 请求数量。这是平台为了保证服务稳定性和公平分配资源而设置的。
>
> * **权益:** 不同的用户或订阅计划可能拥有不同的并发数配额。
> * **超额:** 如果超出并发数限制，新的请求可能会失败或需要排队等待。
>
> 如果您的应用需要高并发处理，请检查您的账户权益或联系平台支持。

***

希望这份文档能帮助您更好地理解和使用 API 的核心参数！


This documentation is built and hosted on [Mintlify](https://mintlify.com), a developer documentation platform.