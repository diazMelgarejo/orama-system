# Live probe results: W&B Inference, BigModel and Cline 3.0.74 (2026-11-12)

Run by Claude Code on the Mac (claude-sonnet-5-5, self-reported) with the operator's go ("yes to all once"). Keys came from the environment and were never printed; every output was scrubbed for the key before it was saved. Tiny prompts only (max 1,500 tokens, a few cents in total). Cline runs used a throwaway `--config` directory and an empty working directory, so the operator's `~/.cline` was never touched. Evidence labels: **LIVE** = observed today; **OFFICIAL** = vendor docs (BigModel's Chinese pages, translated by me); **UNVERIFIED** = not observed.

## 1. Operator rulings applied
1. Effort rule (final, operator 2026-11-12): use `medium`; only if no `medium` works fall back to `high`; if no `high` works, last fallback is `low`. Never `xhigh` or `max`. Applies to every route, template, skill and Cline flag. Always send the level explicitly (BigModel's default is `max`).
2. If none of the three is accepted the route is blocked and reported, not silently changed.
3. Model order (final, operator 2026-11-12): always the `*4.1-Flash-1017` model first whenever it is available; if it does not work, fall back to the generic alias (`deepseek-flash` on DeepSeek's own API; on W&B, which lists no such alias, the closest generic entry is the unsuffixed `V4.1-Flash`, an assumption to confirm), and last to a `*4-Flash` model (on W&B today: `V4-Flash-0731`). Both orders are tried in turn: model first, then effort within that model.
3. Use the actual live W&B model id.
4. All three calls authorized once.
5. Ground everything in what the providers actually serve, not in textual conformity. Where a provider can't be called (BigModel balance), use official sources, translated.

## 2. Live W&B model list (GET /v1/models, 24 models; DeepSeek and GLM entries)
`deepseek-ai/DeepSeek-V4.1-Flash`, `deepseek-ai/DeepSeek-V4.1-Flash-1017`, `deepseek-ai/DeepSeek-V4-Flash-0731`, `deepseek-ai/DeepSeek-V4-Pro-0813`, `deepseek-ai/DeepSeek-V3.1`, `zai-org/GLM-5.3`, `zai-org/GLM-5.3-Flash`, `zai-org/GLM-5.2`.
- **LIVE:** the template's `deepseek-ai/DeepSeek-V4-Flash` is not listed and returns HTTP 404. The template is broken.
- BigModel `GET /models` (12 models) lists `glm-5.3-flash`, `glm-5.3-flashx`, `glm-5.3`, `glm-5.2` and others.

## 3. Direct API probes (prompt: 17*23, expected 391)
| Route / model | effort sent | Result |
| --- | --- | --- |
| W&B `DeepSeek-V4.1-Flash` | medium | **HTTP 400** `{"message":"Invalid request","type":"Bad Request"}` |
| same | high / low / none sent | 200, answer 391, reasoning returned |
| W&B `DeepSeek-V4.1-Flash-1017` | medium | **HTTP 400**, same body |
| W&B `DeepSeek-V4-Flash-0731` | medium | 200, 391 |
| W&B `DeepSeek-V4-Flash` (template id) | medium | **HTTP 404** not found |
| W&B `zai-org/GLM-5.3-Flash` | medium / high / low | 200, 391; **23–30 s per call** (DeepSeek ≈ 1 s) |
| BigModel `glm-5.3-flash` | medium | **HTTP 400**, code 1210: "this model always thinks and can't turn thinking off; use low, high or max" |
| BigModel `glm-5.3-flash` | high / low / none sent | **HTTP 429**, code 1113: balance insufficient or no resource package, please recharge |

Findings:
- **The bare "Bad Request" is explained.** Cline's bare `--thinking` and `--thinking medium` send `reasoning_effort: "medium"`, which W&B rejects on V4.1-Flash and V4.1-Flash-1017 with exactly that body. This is the strongest candidate for the August failure. Today's cause is `medium`; the August model id was different, so that earlier run is not proven to be the same.
- **The `reasoning_content` pass-back hypothesis was not reproduced.** On a tool turn, V4.1-Flash and V4-Flash-0731 returned no `reasoning_content`, and the follow-up turn succeeded both with and without it. Not a cause on W&B for these two models in this simple case.
- **BigModel's `medium` is rejected with an error, not silently turned into `max`.** My earlier claim (from Reply A) was wrong for GLM-5.3-Flash. See section 5.
- **BigModel is blocked by the account, not by the code.** The key authenticates and validation runs, then billing refuses. Nothing beyond validation can be tested live until the operator recharges. I will not pay or top up.

## 4. Cline 3.0.74 runs (throwaway config; task: run `echo hello` with the command tool, reply with the output)
| Run | Result |
| --- | --- |
| W&B V4.1-Flash, `--thinking medium` | **FAIL**, exit 1, `error: Invalid request`, 2.4 s |
| W&B V4.1-Flash, `--thinking high` | **PASS**, tool call executed, reply "hello", 4.0 s |
| W&B V4-Flash-0731, `--thinking medium` | **PASS**, 4.7 s |
| W&B GLM-5.3-Flash, `--thinking high`, provider timeout 30 s | **PASS**, 48.2 s wall (a two-step tool run) |
| W&B GLM-5.3-Flash, `--thinking high`, provider timeout 120 s | see section 7 |

Also confirmed by `cline --help` on 3.0.74: `--thinking none|low|medium|high|xhigh`, `-P`, `-m`, and a `--config <path>` option. The `--config` option gives real isolation of the provider slot per run, which settles the "separate working directories don't isolate settings" worry from the PT recall: use a separate config directory, not a separate working directory.

## 5. BigModel official sources, translated (the account can't be called, so these are the evidence)
- **Effort (OFFICIAL, [chat API](https://docs.bigmodel.cn/api-reference/%E6%A8%A1%E5%9E%8B-api/%E5%AF%B9%E8%AF%9D%E8%A1%A5%E5%85%A8.md), [parameters](https://docs.bigmodel.cn/cn/guide/start/concept-param.md)):** `reasoning_effort` "controls reasoning depth when thinking is on; default `max`; only GLM-5.2 and above". For GLM-5.3 and GLM-5.3-Flash only `low`, `high` and `max` are supported. For GLM-5.2, `medium` and `low` map to `high` and `xhigh` maps to `max`.
- **Consequence:** omitting `reasoning_effort` on `glm-5.3-flash` means **`max`**, which breaks the never-max rule. The template must always send an explicit `high`.
- **Thinking (OFFICIAL, [thinking mode](https://docs.bigmodel.cn/cn/guide/capabilities/thinking-mode.md)):** GLM-5.3 and 5.3-Flash force thinking on and it can't be disabled. With interleaved thinking plus tools, the reasoning content must be kept and returned together with the tool results. So on BigModel the pass-back hypothesis is a documented requirement, unlike on W&B.
- **Limits (OFFICIAL, parameters page):** `glm-5.3-flash` context 1M; default `max_tokens` 65,536; maximum 131,072. So the skill's "131,072 and 65,536" are not simply stale: they are the max-output and default-output figures. What is stale is calling 131,072 the context window.
- **Price (OFFICIAL, [pricing](https://docs.bigmodel.cn/cn/guide/start/pricing)):** CNY per million tokens; glm-5.3-flash input 0.8, output 2.8, cache hit 0.23, cache storage free for a limited time.
- **Errors (OFFICIAL, [error codes](https://docs.bigmodel.cn/cn/faq/api-code.md)):** 1113 = HTTP 429, account in arrears, recharge and retry; 1210 = HTTP 400, invalid API parameters. Both match what the live calls returned.
- **Vendor recommendation conflicts with the operator's rule:** the BigModel model page recommends `reasoning_effort: max`. The operator's rule overrides it.

## 6. Consequences for the templates and policy (what the fix PR must encode)
1. W&B template: replace the model id with a live one (V4.1-Flash, or V4.1-Flash-1017; decision pending, both rejected `medium`).
2. W&B DeepSeek V4.1: `medium` is rejected, so the fallback `high` applies. V4-Flash-0731 accepts `medium`.
3. BigModel GLM-5.3-Flash: no `medium`; use `high`, and always send it explicitly because the default is `max`.
4. Real-life equivalence: `zai-org/GLM-5.3-Flash` on W&B is the same model name as BigModel's `glm-5.3-flash`, so a matched-model comparison is possible once BigModel has balance; today W&B is the only runnable GLM route.
5. Timeouts: GLM on W&B takes 23–30 s per call, so the templates' 30 s timeout is too tight for GLM; DeepSeek on W&B answers in about 1–4 s.
6. The Cline `reasoning` object in the templates (`{"enabled": true}`) must also carry an explicit effort, otherwise Cline may omit it, and BigModel would default to `max`.

## 7. Last Cline run and cleanup
- W&B GLM-5.3-Flash, `--thinking high`, provider timeout 120 s: **PASS**, exit 0, 45.0 s wall. The 30 s and 120 s runs both passed, so the provider-timeout setting did not decide the outcome here; the 23–30 s per-call latency is still the risk, and the timeout field's real effect in Cline 3.0.74 is not established.
- Cleanup: the throwaway config and working directories were removed after each run (none left in the temp folders). The operator's `~/.cline/data/settings/providers.json` still carries its 08:54 modification time from before these runs, so it was not changed.
- Raw outputs (key-scrubbed) are in the session scratchpad probe folder: `effort_probe.txt`, `toolturn_probe.txt`, `cline_wandb_v41_medium.txt`, `cline_wandb_more.txt`.

## 9. Follow-up probes (operator questions, same day)
| W&B model | medium | high | low |
| --- | --- | --- | --- |
| `DeepSeek-V4.1-Flash` | HTTP 400 | 200 | 200 |
| `DeepSeek-V4.1-Flash-1017` | HTTP 400 | 200 | 200 |
| `DeepSeek-V4-Flash-0731` | 200 | not tested | not tested |
| `DeepSeek-V4-Pro-0813` | 200 | 200 | not tested |
| `zai-org/GLM-5.2` | 200 (10.9 s) | 200 (3.2 s) | not tested |
| `zai-org/GLM-5.3-Flash` | 200 | 200 | 200 |

- Both V4.1-Flash and V4.1-Flash-1017 work with `high` (and `low`); neither accepts `medium`. Either id satisfies the rule, so the choice between them is about pinning, not effort support.
- `medium` works on V4-Pro-0813 and GLM-5.2 on W&B (single trivial prompt each; whether it is mapped internally to another level is not observable from the response).
- BigModel stays official-docs-only: payment is blocked by the operator, so no live BigModel call beyond the 400 and 429 already recorded.

## 8. Not done / still unknown
- BigModel through Cline and a BigModel tool-turn probe: blocked by the account balance (error 1113).
- ClinePass route: not probed here (needs its own entitlement test).
- Which W&B DeepSeek id to adopt, V4.1-Flash or V4.1-Flash-1017.
- Whether `medium` is accepted by W&B on `V4-Pro-0813` and `GLM-5.2` was not tested.
- The current W&B price for V4.1-Flash (three conflicting third-party figures).
- No file in the orama-system repo was changed, no branch or PR was created: the fix PR is authorized but waits on the model-id choice.

## 10. DeepSeek V4.1-Flash vs V4.1-Flash-1017: what the official sources say
Sources (OFFICIAL, DeepSeek): [change log](https://api-docs.deepseek.com/updates), [Models & Pricing](https://api-docs.deepseek.com/quick_start/pricing), [Your First API Call](https://api-docs.deepseek.com/). W&B: [models doc](https://docs.wandb.ai/inference/models).
- **What it is:** `1017` is a later upgrade of the same model line. DeepSeek released V4.1-Flash on 2026-09-10 (its news page says Sep 9; the one-day gap is unexplained) and upgraded it to `DeepSeek-V4.1-Flash-1017` on 2026-10-17. The name appears to follow the 10-17 date; DeepSeek doesn't say so explicitly.
- **DeepSeek's rationale ("Performance-cost Pareto improvement"):** better benchmark scores than the previous V4.1 (for example HLE without tools 42.6, DeepSWE v1.1 77.0 against 74.2 for the September release, Terminal-Bench 4.0 42.3 against 31.2), while the model's task runtime and output length were reduced. It was specifically optimized for DeepSeek Harness, Tencent CodeBuddy, WorkBuddy and similar platforms; DeepSeek asks users to upgrade DeepSeek Harness to 0.2.1-rc.1 or later.
- **Official guidance:** call the alias `deepseek-flash`. It is now served by V4.1-Flash-1017, the calling method and pricing are unchanged, and the retired names `deepseek-v4-flash` and `deepseek-v4-flash-vision-exp` are routed to 1017. DeepSeek's own API no longer offers the September snapshot at all.
- **Official limits and price (DeepSeek's own API, not W&B):** context 1M, maximum output 384K, vision supported, thinking on by default. Per 1M tokens off-peak: $0.15 input (cache miss), $0.003 cache hit, $0.6 output; peak hours are double (01:00-04:00 and 06:00-10:00 UTC on weekdays).
- **W&B's two entries:** both list context 1049k and "Text, Vision". W&B's active/total parameter figures differ: 16B-552B for `V4.1-Flash` and 16B-763B for `V4.1-Flash-1017`. W&B does not say how its unsuffixed id relates to DeepSeek's September snapshot, so treat the unsuffixed id as the older, unpinned entry. That mapping is my inference, not a stated fact.
- **Live behaviour (section 9):** identical on the effort probe, with `medium` rejected on both and `high`/`low` accepted.
- **Recommendation (changes my earlier lean):** adopt `deepseek-ai/DeepSeek-V4.1-Flash-1017`. It is the version DeepSeek itself now serves and recommends, and it is a pinned name that will not drift. The unsuffixed id could be repointed or retired by W&B, as the bare `V4-Flash` already was. Operator decision still pending.
- **Effort per the new rule on this model:** try `medium` (rejected on W&B today), then `high` (accepted). A client that tries levels in order will land on `high`.

## 11. Alias and OpenRouter checks (live, same day)
- W&B: `deepseek-ai/deepseek-flash` and `deepseek-flash` both return HTTP 404. W&B does not serve the alias, so on W&B the model order is `V4.1-Flash-1017` → `V4.1-Flash` → `V4-Flash-0731`, with the alias dropped as the operator instructed.
- OpenRouter public model list (no key): has `deepseek/deepseek-v4.1-flash-1017`, `deepseek/deepseek-v4.1-flash`, `deepseek/deepseek-v4-flash-0731`, `deepseek/deepseek-v4-flash`, and the alias `~deepseek/deepseek-flash-latest`. It has **no** `deepseek/deepseek-v4-flash:free`, which four tracked orama-system files still list. Those are stale (see the PR plan).
- Stale configs found in orama-system: `config/mac-orchestrator.json` gives `glm-5.3-flash` a `contextWindow` of 131072 (official: 1M) and zero cost (official price list: 0.8 in / 2.8 out CNY per 1M, with a "free for a limited time" column that I could not interpret).

## 12. Implementation results (local branch, not pushed)
- Branch `2026-11-12-001-cline-provider-live-fixes`, commit `c831947f`, 21 files; tests green for the touched areas (146 passed across the new resolver and template tests, the existing switch tests, the BigModel skill tests and the portal state tests).
- Live resolver check with the new code: W&B `resolve_route` with real probes returned `deepseek-ai/DeepSeek-V4.1-Flash-1017` at effort `high` (medium rejected, as expected); BigModel returned an inconclusive HTTP 429 (balance), which the code reports as "could not verify" and leaves `providers.json` unchanged.
- Cline 3.0.74 with the new template values (`V4.1-Flash-1017`, `--thinking high`, throwaway config): tool task passed in 3.9 s.
- Found while sweeping stale tails: 6 of the 7 OpenRouter `:free` ids in the free-tier stack are not in OpenRouter's live model list today (only `openrouter/free` is). The DeepSeek one was removed from live code; the other five need an operator decision.

## 13. OpenRouter free-tier replacements (live, same day)
Six `:free` ids in the free-tier stack were absent from OpenRouter's live list. Replacements were chosen from the 13 live free ids by role (context, tool and reasoning support, vendor), then each candidate answered one plain and one tool-call request with a free call.

| Role | Dead id | Replacement | Live result |
| --- | --- | --- | --- |
| A agent brain | `nvidia/nemotron-3-super-120b-a12b:free` | `nvidia/nemotron-3-ultra-550b-a55b:free` (1M, orchestration) | plain 200, tool call yes |
| B coding | `minimax/minimax-m2.5:free` | `cohere/north-mini-code:free` (256K, agentic coding) | 200, tool call yes |
| C fast triage | `deepseek/deepseek-v4-flash:free` | `nvidia/nemotron-3.5-lightning:free` (1M, 3B active) | 200, tool call yes |
| D reasoning + tools | `openai/gpt-oss-120b:free` | `nvidia/nemotron-3.5-super-vl:free` (1M) | 200, tool call yes |
| E agentic backup | `z-ai/glm-4.5-air:free` | `baidu/ernie-5.5-flash-preview:free` (1M, preview model) | 200, tool call yes |
| F lightweight | `inclusionai/ling-2.6-flash:free` | `liquid/lfm-3-1.7b:free` (256K; states prompts may be retained) | 200, tool call yes |
| Z last resort | `openrouter/free` (already live) | unchanged | not re-probed |

Not chosen: `google/gemma-4-31b-it:free` and `google/gemma-4-26b-a4b-it:free` (HTTP 429, rate-limited upstream at probe time, inconclusive), `thinkingmachines/inkling-2-small:free` (HTTP 403, only for agentic harnesses), `recursive/flint-v1.0:free` (works, kept as an alternate for D to reduce NVIDIA concentration, three of the six picks are NVIDIA).

## 14. Effort cadence rule (operator, 2026-11-12, after a side-agent note)
The new templates carry a fixed `high` (last live-verified). That value is applied on every switch, so rule and syntax updates stay applied. The medium, high, low walk runs only through the opt-in `--resolve --verify-effort`, as a periodic re-check during reviewed repository updates (live model list, effort probes, a tool task in a throwaway Cline config), not as a per-switch billed cost. Documented in the cline-wandb and glm52-fallback skills and the switch script header; recorded as PT lesson `lesson_7d306abe607f` (separate local PT branch, not pushed) and in the private memory.

## 15. Branch status
orama-system branch `2026-11-12-001-cline-provider-live-fixes`: two local commits (`c831947f`, `912bb0f3`), not pushed, no PR. PT branch `2026-11-12-001-effort-recheck-lesson`: one local commit (`d5b99399`), not pushed. Publishing is on hold by the operator. Left for a separate change: web UI mock labels (TDD gate needs an adjacent test).

